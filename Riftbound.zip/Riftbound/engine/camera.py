"""
Riftbound Camera Module
Handles camera setup and positioning for fighting game view
"""

from ursina import camera


# ============================================================
# CAMERA CONFIGURATION
# ============================================================

DEFAULT_CAMERA_POSITION = (0, 7, -18)
DEFAULT_CAMERA_ROTATION = (15, 0, 0)


# ============================================================
# CAMERA SETUP
# ============================================================

def setup_camera():
    """Initialize camera position and rotation for fighting game view"""
    camera.position = DEFAULT_CAMERA_POSITION
    camera.rotation_x = DEFAULT_CAMERA_ROTATION[0]
    camera.rotation_y = DEFAULT_CAMERA_ROTATION[1]
    camera.rotation_z = DEFAULT_CAMERA_ROTATION[2]
    print("✓ Camera configured")


def update_camera_facing(fighter1, fighter2):
    """
    Update character facing directions so they look at each other.
    
    Args:
        fighter1: First fighter entity
        fighter2: Second fighter entity
    """
    # Fighter 1 faces opponent
    if fighter2.x > fighter1.x:
        fighter1.rotation_y = 0      # Face right
    else:
        fighter1.rotation_y = 180    # Face left

    # Fighter 2 faces opponent
    if fighter1.x > fighter2.x:
        fighter2.rotation_y = 180    # Face left
    else:
        fighter2.rotation_y = 0      # Face right


def get_camera_info():
    """Return current camera position and rotation info"""
    return {
        'position': camera.position,
        'rotation': (camera.rotation_x, camera.rotation_y, camera.rotation_z)
    }
