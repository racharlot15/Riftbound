"""
Riftbound Combat System Module
Defines attack data, damage calculation, and combat mechanics
"""

# ============================================================
# ATTACK DATABASE
# ============================================================

ATTACKS = {
    "LIGHT": {
        "startup": 0.10,    # Time before hitbox appears
        "active": 0.10,     # Time hitbox is active
        "recovery": 0.18,   # Time after active frames
        "damage": 5,
        "knockback": 2.5,
        "hitstun": 0.20,    # How long opponent is stunned
        "range": 2.0,       # Horizontal reach
        "height": 1.5       # Vertical reach
    },

    "MEDIUM": {
        "startup": 0.16,
        "active": 0.12,
        "recovery": 0.25,
        "damage": 9,
        "knockback": 4,
        "hitstun": 0.28,
        "range": 2.3,
        "height": 1.5
    },

    "HEAVY": {
        "startup": 0.25,
        "active": 0.14,
        "recovery": 0.35,
        "damage": 14,
        "knockback": 6,
        "hitstun": 0.40,
        "range": 2.6,
        "height": 1.8
    },

    "LAUNCHER": {
        "startup": 0.22,
        "active": 0.12,
        "recovery": 0.30,
        "damage": 10,
        "knockback": 3,
        "hitstun": 0.35,
        "range": 2.2,
        "height": 2.5
    }
}


# ============================================================
# COMBAT CONSTANTS
# ============================================================

BLOCK_DAMAGE_REDUCTION = 0.8   # Blocks reduce damage by 80%
MIN_BLOCK_DAMAGE = 1           # Minimum damage even when blocking
COMBO_DECAY_TIME = 1.5         # Seconds before combo counter resets


# ============================================================
# COMBAT HELPER FUNCTIONS
# ============================================================

def get_attack_data(attack_name):
    """Retrieve attack data by name"""
    return ATTACKS.get(attack_name)


def calculate_block_damage(raw_damage):
    """Calculate reduced damage when blocking"""
    return max(MIN_BLOCK_DAMAGE, int(raw_damage * BLOCK_DAMAGE_REDUCTION))


def calculate_knockback_direction(attacker_x, target_x, knockback_value):
    """
    Determine knockback direction based on positions.
    
    Returns:
        float: Positive or negative knockback velocity
    """
    if attacker_x < target_x:
        return knockback_value   # Knock target right
    else:
        return -knockback_value  # Knock target left


def get_attack_phase(timer, startup, active, recovery):
    """
    Determine which phase of an attack we're in.
    
    Returns:
        str: 'startup', 'active', 'recovery', or 'complete'
    """
    active_end = startup + active
    recovery_end = active_end + recovery
    
    if timer < startup:
        return 'startup'
    elif timer < active_end:
        return 'active'
    elif timer < recovery_end:
        'recovery'
        return 'recovery'
    else:
        return 'complete'
