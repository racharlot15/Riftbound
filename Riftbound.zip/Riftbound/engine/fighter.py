"""
Riftbound Fighter Module
Core Fighter class with movement, combat, and physics systems
"""

from ursina import Entity, Text
from .hitbox import AttackHitbox
from .combat import ATTACKS, COMBO_DECAY_TIME


# ============================================================
# PHYSICS CONSTANTS
# ============================================================

GRAVITY = 22
JUMP_FORCE = 11
VARIABLE_GRAVITY_MULTIPLIER = 1.4   # Extra gravity when falling/releasing jump early
MAX_FALL_SPEED = 20                  # Terminal velocity

# Jump timing windows (in seconds)
COYOTE_TIME = 0.08          # Can jump briefly after leaving ground
JUMP_BUFFER_TIME = 0.10     # Press jump before landing, still jumps

# Movement speeds
MOVE_SPEED = 7
AIR_MOVE_SPEED = 5          # Slightly slower movement in air


class Fighter(Entity):
    """
    Core fighter entity with complete fighting game mechanics.
    
    Handles:
    - Health and combat state
    - Movement (ground + air)
    - Jump physics with variable height
    - Attack execution and hit detection
    - Hitstun and knockback
    """

    def __init__(self, name, position, fighter_color):
        
        super().__init__(
            model="cube",
            scale=(1, 2, 1),
            position=position,
            color=fighter_color
        )

        self.fighter_name = name

        # ----------------------------------------------------
        # HEALTH SYSTEM
        # ----------------------------------------------------

        self.max_health = 100
        self.health = 100

        # ----------------------------------------------------
        # COMBAT STATE MACHINE
        # ----------------------------------------------------

        self.state = "IDLE"           # Current state: IDLE, WALK, JUMP, ATTACK, BLOCK, HITSTUN, KO
        self.attack_name = None       # Current attack being performed
        self.attack_timer = 0         # Timer for current attack phase
        self.attack_hit = False       # Whether this attack has already hit

        self.hitstun_timer = 0        # Remaining hitstun duration
        self.knockback_velocity = 0   # Current knockback movement speed

        # Combo tracking
        self.combo_count = 0
        self.combo_timer = 0

        # ----------------------------------------------------
        # MOVEMENT & PHYSICS
        # ----------------------------------------------------

        self.vertical_velocity = 0
        self.grounded = True
        
        # Jump system variables
        self.coyote_timer = 0              # Time since leaving ground (for coyote time)
        self.jump_buffer_timer = 0         # Buffered jump input waiting to execute
        self.can_variable_jump = False     # Can we cut jump short by releasing button?
        self.jump_held_this_jump = False   # Track if jump was held this jump cycle

        # ----------------------------------------------------
        # HITBOX
        # ----------------------------------------------------

        self.hitbox = AttackHitbox()
        self.hitbox.owner = self

        # ----------------------------------------------------
        # VISUAL ELEMENTS
        # ----------------------------------------------------

        # Name tag above fighter
        Text(
            text=name,
            parent=self,
            y=1.5,
            origin=(0, 0),
            scale=2
        )

        # Health bar (position set by game setup)
        self.health_bar = None

    # ========================================================
    # STATE MANAGEMENT
    # ========================================================

    def set_state(self, new_state):
        """Transition to a new state"""
        if self.state != new_state:
            
            old_state = self.state
            self.state = new_state
            
            # Clear attack data when leaving combat states
            if new_state not in ("ATTACK", "HITSTUN", "JUMP"):
                self.attack_name = None
            
            print(f"[{self.fighter_name}] {old_state} → {new_state}")

    def can_act(self):
        """Check if fighter can perform actions (not stunned/KO'd)"""
        return self.state not in ("HITSTUN", "KO")

    def is_airborne(self):
        """Check if fighter is currently in the air"""
        return not self.grounded

    # ========================================================
    # ATTACK SYSTEM
    # ========================================================

    def start_attack(self, attack_name):
        """
        Begin an attack if conditions are met.
        
        Args:
            attack_name: Key from ATTACKS dictionary (LIGHT, MEDIUM, HEAVY, LAUNCHER)
        """
        # Check if we can attack
        if self.state in ("ATTACK", "HITSTUN"):
            return False
        
        # Most attacks require being grounded (aerial attacks would be added later)
        if not self.grounded and self.state != "JUMP":
            return False

        # Initialize attack
        self.attack_name = attack_name
        self.attack_timer = 0
        self.attack_hit = False
        self.state = "ATTACK"

        print(f"  ⚔️ {self.fighter_name} attacks: {attack_name}")
        return True

    def update_attack(self, opponent):
        """
        Process current attack through its phases.
        
        Phases: STARTUP → ACTIVE → RECOVERY → COMPLETE
        """
        import time as ursina_time
        
        data = ATTACKS[self.attack_name]
        self.attack_timer += ursina_time.dt

        startup = data["startup"]
        active_end = startup + data["active"]
        recovery_end = active_end + data["recovery"]

        # STARTUP PHASE: Preparing attack, no hitbox yet
        if self.attack_timer < startup:
            self.hitbox.hide_hitbox()
            return 'startup'

        # ACTIVE PHASE: Hitbox is out, can deal damage
        if self.attack_timer < active_end:
            self._update_attack_hitbox(data)
            self.hitbox.show_hitbox()
            
            if not self.attack_hit:
                self._check_attack_hit(opponent, data)
            
            return 'active'

        # RECOVERY PHASE: Attack ending, vulnerable window
        self.hitbox.hide_hitbox()

        if self.attack_timer >= recovery_end:
            # Attack complete - return to appropriate state
            if self.grounded:
                self.set_state("IDLE")
            else:
                self.set_state("JUMP")
            
            self.attack_name = None
            return 'complete'
        
        return 'recovery'

    def _update_attack_hitbox(self, data):
        """Position and size the attack hitbox based on attack data"""
        direction = 1 if self.rotation_y == 0 else -1
        
        self.hitbox.set_position(
            self.x + direction * data["range"] / 2,
            self.y,
            self.z - 1
        )
        
        self.hitbox.set_size(
            data["range"],
            data["height"],
            2
        )

    def _check_attack_hit(self, opponent, data):
        """Check if current attack hits the opponent"""
        if self.hitbox.check_collision(opponent, data["range"], data["height"]):
            opponent.take_hit(data, self)
            self.attack_hit = True

    # ========================================================
    # DAMAGE & HIT REACTIONS
    # ========================================================

    def take_hit(self, data, attacker):
        """
        Process taking damage from an attack.
        
        Args:
            data: Attack data dictionary
            attacker: Fighter who landed the attack
        """
        # BLOCK CHECK
        if self.state == "BLOCK":
            from .combat import calculate_block_damage
            damage = calculate_block_damage(data["damage"])
            self.health -= damage
            print(f"  🛡️ {self.fighter_name} blocked! ({damage} damage)")
            return

        # APPLY DAMAGE
        self.health -= data["damage"]
        self.health = max(0, self.health)

        # ENTER HITSTUN
        self.set_state("HITSTUN")
        self.hitstun_timer = data["hitstun"]

        # APPLY KNOCKBACK
        from .combat import calculate_knockback_direction
        self.knockback_velocity = calculate_knockback_direction(
            attacker.x, 
            self.x, 
            data["knockback"]
        )

        # UPDATE COMBO COUNTER
        attacker.combo_count += 1
        attacker.combo_timer = COMBO_DECAY_TIME

        print(f"  💥 {attacker.fighter_name} hits {self.fighter_name}! (-{data['damage']} HP)")
        if attacker.combo_count > 1:
            print(f"     🔥 {attacker.combo_count}-HIT COMBO!")

        # UPDATE HEALTH BAR
        if self.health_bar:
            self.health_bar.update_health(self.health)

        # CHECK FOR K.O.
        if self.health <= 0:
            self.set_state("KO")
            print(f"  ☠️ {self.fighter_name} KNOCKED OUT!")

    def update_hitstun(self):
        """Process hitstun state - knocked back, unable to act"""
        import time as ursina_time
        
        self.hitstun_timer -= ursina_time.dt
        
        # Apply knockback movement
        self.x += self.knockback_velocity * ursina_time.dt
        
        # Apply gravity during airborne hitstun
        if not self.grounded:
            self.vertical_velocity -= GRAVITY * ursina_time.dt
            self.y += self.vertical_velocity * ursina_time.dt
            
            # Ground check during hitstun
            if self.y <= 1:
                self.y = 1
                self.vertical_velocity = 0
                self.grounded = True

        # Decay knockback velocity
        self.knockback_velocity *= 0.90

        # End hitstun when timer expires
        if self.hitstun_timer <= 0:
            self.set_state("IDLE")

    # ========================================================
    # MOVEMENT SYSTEM
    # ========================================================

    def move_horizontal(self, direction):
        """
        Move fighter horizontally.
        
        Args:
            direction: Movement direction (-1 left, 1 right), can be fractional for smoothing
        """
        import time as ursina_time
        
        if direction == 0:
            return
        
        # Use appropriate speed based on grounded/airborne state
        speed = AIR_MOVE_SPEED if not self.grounded else MOVE_SPEED
        
        self.x += direction * speed * ursina_time.dt
        
        # Update visual state if grounded
        if self.grounded and self.state not in ("ATTACK", "BLOCK"):
            self.set_state("WALK")

    def stop_movement(self):
        """Stop horizontal movement and return to idle if grounded"""
        if self.grounded and self.state not in ("ATTACK", "BLOCK", "HITSTUN"):
            self.set_state("IDLE")

    # ========================================================
    # JUMP PHYSICS SYSTEM
    # ========================================================

    def try_jump(self):
        """
        Attempt to jump. Uses coyote time and input buffering for responsive feel.
        """
        if self.state in ("ATTACK", "HITSTUN", "KO", "BLOCK"):
            # Buffer the jump attempt for when we can act
            if self.state != "KO":
                self.jump_buffer_timer = JUMP_BUFFER_TIME
                print(f"  [BUFFER] {self.fighter_name} buffered jump")
            return
        
        if self.grounded or self.coyote_timer > 0:
            self._execute_jump()
        else:
            # Not grounded - buffer the input
            self.jump_buffer_timer = JUMP_BUFFER_TIME
            print(f"  [BUFFER] {self.fighter_name} buffered jump (airborne)")

    def _execute_jump(self):
        """Actually perform the jump"""
        if self.state in ("ATTACK", "HITSTUN", "KO", "BLOCK"):
            return
        
        # Verify we can still jump (coyote time or grounded)
        can_jump = self.grounded or self.coyote_timer > 0
        if not can_jump:
            return

        # Launch into air
        self.grounded = False
        self.coyote_timer = 0
        self.jump_buffer_timer = 0
        self.vertical_velocity = JUMP_FORCE
        
        # Enable variable height jumping
        self.can_variable_jump = True
        self.jump_held_this_jump = True
        
        self.set_state("JUMP")
        print(f"  ⬆️ {self.fighter_name} jumps!")

    def update_gravity(self):
        """
        Apply gravity and handle ground/air transitions.
        Includes variable jump height and coyote time logic.
        """
        import time as ursina_time
        from ..engine.controller import jump_held
        
        # Update coyote timer when grounded
        if self.grounded:
            self.coyote_timer = COYOTE_TIME
        else:
            # Decrease coyote timer when airborne
            self.coyote_timer = max(0, self.coyote_timer - ursina_time.dt)

        # Process buffered jump input
        if self.jump_buffer_timer > 0:
            self.jump_buffer_timer = max(0, self.jump_buffer_timer - ursina_time.dt)
            if self.grounded and self.jump_buffer_timer > 0:
                self._execute_jump()
                return

        # No gravity processing if grounded
        if self.grounded:
            self.can_variable_jump = False
            self.jump_held_this_jump = False
            return

        # Apply base gravity
        self.vertical_velocity -= GRAVITY * ursina_time.dt
        
        # Variable jump height: extra gravity when:
        # 1. Falling (moving down) - always apply
        # 2. Rising but jump button released - allows short hops
        should_cut_jump = (
            self.vertical_velocity < 0 or 
            (self.can_variable_jump and not jump_held() and self.vertical_velocity > 0)
        )
        
        if should_cut_jump:
            extra_gravity = GRAVITY * (VARIABLE_GRAVITY_MULTIPLIER - 1)
            self.vertical_velocity -= extra_gravity * ursina_time.dt
        
        # Clamp to terminal velocity
        self.vertical_velocity = max(self.vertical_velocity, -MAX_FALL_SPEED)

        # Apply vertical movement
        self.y += self.vertical_velocity * ursina_time.dt

        # Ground collision
        if self.y <= 1:
            self.y = 1
            self.vertical_velocity = 0
            self.grounded = True
            
            # Return to idle if we were just jumping/falling
            if self.state == "JUMP":
                self.set_state("IDLE")

    # ========================================================
    # COMBO SYSTEM
    # ========================================================

    def update_combo_timer(self):
        """Decay combo counter over time"""
        import time as ursina_time
        
        if self.combo_timer > 0:
            self.combo_timer -= ursina_time.dt
        else:
            self.combo_count = 0

    # ========================================================
    # UTILITY METHODS
    # ========================================================

    def get_info(self):
        """Return dict of current fighter state for debugging/UI"""
        return {
            'name': self.fighter_name,
            'state': self.state,
            'health': self.health,
            'max_health': self.max_health,
            'position': (round(self.x, 2), round(self.y, 2)),
            'grounded': self.grounded,
            'attack': self.attack_name,
            'combo': self.combo_count
        }

    def clamp_to_arena(self, arena_width):
        """Keep fighter within arena boundaries"""
        half = arena_width / 2
        self.x = max(-half + 1, min(half - 1, self.x))
