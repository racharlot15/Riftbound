"""
Riftbound Hitbox Module
Handles attack hitbox visualization and collision detection
"""

from ursina import Entity, color


class AttackHitbox(Entity):
    """
    Visual representation of attack hit area.
    Only visible during active frames of attacks.
    """

    def __init__(self):

        super().__init__(
            model="cube",
            color=color.rgba(
                255,
                80,
                80,
                80  # Semi-transparent red
            ),
            visible=False
        )

        self.owner = None
        self.attack_name = None

    def show_hitbox(self):
        """Make hitbox visible for collision checking"""
        self.show()

    def hide_hitbox(self):
        """Hide hitbox when not active"""
        self.hide()

    def set_position(self, x, y, z):
        """Update hitbox position"""
        self.position = (x, y, z)

    def set_size(self, width, height, depth):
        """Update hitbox dimensions"""
        self.scale = (width, height, depth)

    def check_collision(self, target, range_val, height_val):
        """
        Check if this hitbox collides with a target fighter.
        
        Args:
            target: Fighter entity to check against
            range_val: Horizontal reach of attack
            height_val: Vertical reach of attack
        
        Returns:
            bool: True if collision detected
        """
        distance_x = abs(self.x - target.x)
        distance_y = abs(self.y - target.y)

        # Check if within hitbox bounds (accounting for target body size)
        hit_threshold_x = range_val / 2 + 0.6   # Target body half-width
        hit_threshold_y = height_val / 2 + 1     # Target body half-height

        if distance_x <= hit_threshold_x and distance_y <= hit_threshold_y:
            return True
        
        return False
